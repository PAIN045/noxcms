<?php
 
namespace models;

use vendor\db\ActiveRecord;

class Users extends ActiveRecord {

    
}        

    
    