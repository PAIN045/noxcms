<?php

namespace controller;

use models\Users;
use vendor\nox\Nox;
use vendor\nox\Controller;

	class ControllerUser  extends Controller {
		
		
		public function actionIndex()
		{
			
			return $this->tpl->render('user.index');
			
		}
		
		public function actionError()
		{
			http_response_code(404);
			return $this->tpl->render('index.error');
			
		}
		
		
	}