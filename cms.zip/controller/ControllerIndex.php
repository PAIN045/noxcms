<?php

namespace controller;

use models\Users;
use vendor\nox\Nox;
use vendor\nox\Controller;

	class ControllerIndex  extends Controller {
		
		public function actionIndex($id = null)
		{
		
			$user = Users :: findOne(['id' => 1]);
			
			$sql = new \vendor\db\Command('select * from users where id = ?');
			
			echo $sql->obj([1])->username;
		
		
		return $this->tpl('index', ['title' => 'NOXCMS']);
			
		}
		
		public function actionError()
		{
			http_response_code(404);
			return $this->tpl('error');
			
		}
		
		
	}