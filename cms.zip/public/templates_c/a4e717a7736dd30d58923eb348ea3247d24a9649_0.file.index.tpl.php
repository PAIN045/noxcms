<?php
/* Smarty version 3.1.39, created on 2021-07-26 16:35:52
  from 'D:\OpenServer\domains\cms\templates\index\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60feba38d443d4_73431228',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a4e717a7736dd30d58923eb348ea3247d24a9649' => 
    array (
      0 => 'D:\\OpenServer\\domains\\cms\\templates\\index\\index.tpl',
      1 => 1627306541,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60feba38d443d4_73431228 (Smarty_Internal_Template $_smarty_tpl) {
}
}
