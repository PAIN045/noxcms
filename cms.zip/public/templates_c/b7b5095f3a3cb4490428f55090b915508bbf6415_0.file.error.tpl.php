<?php
/* Smarty version 3.1.39, created on 2021-07-26 16:42:19
  from 'D:\OpenServer\domains\cms\templates\error.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60febbbbecb6a3_29520744',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b7b5095f3a3cb4490428f55090b915508bbf6415' => 
    array (
      0 => 'D:\\OpenServer\\domains\\cms\\templates\\error.tpl',
      1 => 1627224006,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60febbbbecb6a3_29520744 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
<div class="site-error">

    <h1>Not Found (#404)</h1>

    <div class="alert alert-danger">
        Страница не найдена.    </div>
</div>
</div>
<?php }
}
