<?php
/* Smarty version 3.1.39, created on 2021-07-26 16:35:52
  from 'D:\OpenServer\domains\cms\templates\layout\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60feba38d6f355_54388989',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '66d58bf7849a8c2d90391eeb56952296d15aa8a3' => 
    array (
      0 => 'D:\\OpenServer\\domains\\cms\\templates\\layout\\main.tpl',
      1 => 1627306552,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60feba38d6f355_54388989 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
  <html lang="ru">

  <head>
    <meta charset="utf-8" />
    <title>
	<?php echo $_smarty_tpl->tpl_vars['title']->value;?>

    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <?php echo $_smarty_tpl->tpl_vars['assets']->value->Meta();?>

		<?php echo $_smarty_tpl->tpl_vars['assets']->value->Head();?>


  </head>
   <body>
   
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

      

        <?php echo $_smarty_tpl->tpl_vars['assets']->value->endBody();?>

  </body>

  </html> <?php }
}
