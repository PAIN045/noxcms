<?php
	
	session_start();
	
	define('__ROOT__',$_SERVER['DOCUMENT_ROOT']);

	require (__ROOT__.'/vendor/autoload_real.php');
	

	
	
	
	
	
	echo \vendor\web\App :: Run();


