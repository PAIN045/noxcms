<?php

	return  

			['host' => 'localhost',
			 'username' => 'root',
			 'dsn' => 'noxcms',
			 'password' => 'root'
			];
			
			
	