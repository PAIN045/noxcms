<?php

###NOXCMS
###Developer: https://github.com/PAIN045
###telegram: @pain045


	$db = require __DIR__.'/db.php';
	
	return 
		['app' =>
			
			['name' => 'NOXCMS',
			 
			],
		 
		 'lang' => 
			
		
			
			['ru' => 'ru', 'en' => 'en']
			
			,
			
		 'db' => $db,
		 
		 'user' => \vendor\nox\Nox::User(),
		 
		 'url' =>
		 
		 ['index/index' => 'index/index',
		  'test' => 'index/test',
		  'sign-up' => 'index/signup',
		  'user' => 'user/index',
		 
		 ]
				
				];