<?php

namespace widget;

use vendor\nox\Nox;
use vendor\web\Request;
use vendor\web\ActiveForm;


	class LangWidget {
		
		
		public static function Run()
		{
		
		
	$_lang = Request :: session('lang') ?? 'ru';
	$ActiveForm = new ActiveForm();

	
		return $ActiveForm->Button(['class' => 'btn btn-default', 
									'value' => '<img src="/images/lang/'.$_lang.'.png"> '.mb_strtoupper($_lang),
									'data-toggle' => 'modal',
									'data-target' => '#langChange'
									]);
		
		}
		
		
		public static function Select()
		{
			
			return $_lang = Request :: session('lang') ?? 'ru';
			
			
		}
		
	}
